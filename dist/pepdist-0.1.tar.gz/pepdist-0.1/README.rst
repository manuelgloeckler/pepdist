pepdist
--------

To use, simply do::

    >>> import funniest